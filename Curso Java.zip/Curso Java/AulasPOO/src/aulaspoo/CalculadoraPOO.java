/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulaspoo;

/**
 *
 * @author adrie
 */

//EXEMPLIFICANDO POLIMORFISMO DE SOBRECARGA
public class CalculadoraPOO {
    
    public int somar (int n1, int n2){
        int soma = n1 + n2;
        return soma;
    }
    
    public int somar (int n1, int n2, int n3){
        int soma = n1 + n2 + n3;
        return soma;
    }
    
     public double somar (double n1, double n2){
        double soma = n1 + n2;
        return soma;
    }
     
     public static void main (String [] args){
         CalculadoraPOO calc = new CalculadoraPOO();
         System.out.println(calc.somar(7, 2));
         System.out.println(calc.somar(7, 8, 10));
         
     }
    
}
