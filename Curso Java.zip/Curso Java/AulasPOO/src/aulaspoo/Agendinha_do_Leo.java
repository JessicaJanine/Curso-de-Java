/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulaspoo;

/**
 *
 * @author adrie
 */
public class Agendinha_do_Leo {
    public static void main(String[] args){
            Agendinha agenda1 = new Agendinha();
            Agendinha agenda2 = new Agendinha();
            
            agenda1.anote(12, 10, "Dia da criança");
            agenda2.anote(7, 9, "Independência do Brasil");
            
            agenda1.mostraAnotacao();
            agenda2.mostraAnotacao();
    }
}
