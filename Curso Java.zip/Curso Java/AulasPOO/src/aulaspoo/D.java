/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulaspoo;

/**
 *
 * @author adrie
 */
public class D {
    public void meuMetodo(F f){
     
        G g = new G();
        
        System.out.println ("D");
        
            
        f.meuMetodo(g);
    }
}
