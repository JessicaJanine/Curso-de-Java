/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulaspoo;

/**
 *
 * @author adrie
 */
public class Carro {
    String tipo;
    String cor;
    String placa;
    int numPortas;
    Donos dono;
    int marcha;
    
    public Carro(String tipo, String cor, String placa, int numPortas, String dono){
        this.tipo = tipo;
        this.cor = cor;
        this.placa = placa;
        this.numPortas = numPortas;
    }
    
    public Carro(){
        System.out.println("Haha construtor");
    }
    
    
    
    public void setCor(String c){
        cor = c;
    }
   
    
    public String getCor() {
        return cor;
    }
    
    
    public String getTipo(){
      return tipo;
    }
    
   public void setTipo(String tipo){
        this.tipo = tipo;
    }
    
    public String getPlaca(){
        return placa;
    }
    
   public void setPlaca(String placa){
        this.placa = placa;
    }
    
    public int getNumPortas(){
        return numPortas;
    }
    
    public void setNumPortas(int numPortas){
        this.numPortas = numPortas;
    }
    
    public Donos getDono(){
        return dono;
    }
    
    public void setDono(Donos dono){
        this.dono = dono;
    }
    public void ligar(){
        System.out.println("Carro ligado");
    }
    public void desligar(){
        System.out.println("Carro desligado");
    }
    public void acelerar(){
        System.out.println("acelerando...");
    }
    public void frear(){
        System.out.println("freando...");
    }
    public void setCambio(int marcha){
        this.marcha = marcha;
    }
    public int getCambio(){
        return this.marcha;
    }
}
