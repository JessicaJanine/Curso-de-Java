/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulaspoo;

/**
 *
 * @author adrie
 */
public class Motor {
  private int potencia;
  public int getPotencial(){
      return this.potencia;
  }
  public void setPotencial(int potencia){
      this.potencia = potencia;
  }
}
