/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulaspoo;

/**
 *
 * @author adrie
 */
public class Principal {
    public static void main (String[] args){
        Carro novoCarro = new Carro("Passeio", "Preto", "NOX020202", 4, "01234567");
        Carro novoCarro2 = new Carro();
        novoCarro2.setCor("vermelho");
        novoCarro2.setNumPortas(4);
        novoCarro2.setPlaca("JSjibw");
        novoCarro2.setTipo("Esportivo");
        
        
        Donos novoDono2 = new Donos();
        novoDono2.setNome("Claudete");
       
        novoDono2.setCarro(novoCarro2);
        
        novoDono2.ligarCarro();
        novoDono2.setCambioCarro(1);
        novoDono2.acelerarCarro();
        novoDono2.setCambioCarro(2);
        novoDono2.acelerarCarro();
        novoDono2.setCambioCarro(3);
        novoDono2.acelerarCarro();
        novoDono2.setCambioCarro(2);
        novoDono2.acelerarCarro();
        novoDono2.setCambioCarro(1);
        novoDono2.acelerarCarro();
        novoDono2.setCambioCarro(0);
        novoDono2.frearCarro();
        novoDono2.desligarCarro();
     
    }
}

