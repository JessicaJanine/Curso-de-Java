/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulaspoo;

/**
 *
 * @author adrie
 */
public class Automovel {
    private Motor motor;
    private Direcao direcao;
    public Motor getMotor(){
        return this.motor;
    }
    public void setMotor(Motor motor){
        this.motor = motor;
    }
    public Direcao getDirecao(){
        return this.direcao;
    }
    public void setDirecao(Direcao direcao){
        this.direcao = direcao;
    }
    
}
