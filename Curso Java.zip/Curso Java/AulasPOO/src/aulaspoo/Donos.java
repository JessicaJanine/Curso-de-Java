/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package aulaspoo;

/**
 *
 * @author adrie
 */
public class Donos {
    String Nome;
    Carro carro;

    public Donos(){
        
    }
    public void setNome(String Nome){
    this.Nome = Nome;

}
    public String getNome(){
        return Nome;
    }
    
    public Carro getCarro(){
        return carro;
    }
    public void setCarro(Carro carro){
        this.carro = carro;
    }
    public void ligarCarro(){
        carro.ligar();
    }
    public void desligarCarro(){
        carro.desligar();
    }
    public void acelerarCarro(){
        carro.acelerar();
    }
    public void frearCarro(){
        carro.frear();
    }
    public void setCambioCarro(int cambio){
        carro.setCambio(cambio);
    }
}