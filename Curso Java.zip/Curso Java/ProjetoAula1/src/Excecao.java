
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author adrie
 */
public class Excecao {
    public static int quociente (int numerador, int denominador) throws ArithmeticException {
        return numerador/denominador;
    }
    
    public static void main (String[] args){
        try{
            Scanner leitor = new Scanner(System.in);
            System.out.println("Digite o numerador");
            int numerador = leitor.nextInt();
            System.out.println("Digite o denominador");
            int denominador = leitor.nextInt();
            double resultado = quociente(numerador, denominador);
            System.out.println(resultado);
                            
        } catch (ArithmeticException erro) {
            System.err.println("Erro " + erro);
            System.out.println("0 não é um denominador válido");
        }
        finally{
            System.out.println("FIM");
        }
    }
    }
