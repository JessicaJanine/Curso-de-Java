/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoaula1;

import java.io.Serializable;

/**
 *
 * @author adrie
 */
public class registroJogador implements Serializable {
    public String nome;
    public int vitorias;
    public int derrotas;
}
