/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoaula1;
import java.util.Scanner;
/**
 *
 * @author adrie
 */
public class Aula12 {
    //REGISTROS e ENUMERAÇÕES
    //REGISTROS = Devem ser criados em uma classe separada.
    public static void main(String[] args){
        Scanner leitor = new Scanner(System.in);
        registroEndereco end = new registroEndereco();
        System.out.println("Digite a rua onde você mora: ");
        end.rua = leitor.nextLine();
        System.out.println("Digite o número da residência: ");
        end.numero = leitor.nextInt();
        leitor.nextLine();
        System.out.println("Digite o bairro: ");
        end.bairro = leitor.nextLine();
        System.out.println("Digite a cidade: ");
        end.cidade = leitor.nextLine();
        System.out.println("Digite o estado: ");
        end.estado = leitor.nextLine();
        System.out.println("Digite o CEP: ");
        end.CEP = leitor.nextLine();
        System.out.println("----------- Seu endereço é -----------------");
        System.out.println(end.rua + "," + end.numero);
        System.out.println(end.bairro + "," + end.cidade);
        System.out.println("CEP: " + end.CEP + "," + end.estado);
    }
}
