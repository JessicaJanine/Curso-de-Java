/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoaula1;

import java.util.Scanner;

/**
 *
 * @author adrie
 */
public class Aula2 {
    public static void main (String args[]){
        int a = 3 - 2 * 5;
        int base = 30;
        int altura = 20;
        int area = base * altura;
        System.out.println("\t Bons estudos");
        System.out.println("Bom dia, Carol!\nSabemos que a aula foi gravada pra vc, Carol");
        System.out.println("Seja bem-vindo à mais uma vídeo aula");
        System.out.println(a);
        System.out.println("Meu nome é Adrielly Lindona");
        System.out.println(area);
        
        Scanner leitor = new Scanner(System.in);
        System.out.println("Digite seu nome");
        String nome = leitor.nextLine();
        System.out.println("Olá " + nome);
    }
}
