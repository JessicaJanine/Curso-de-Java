/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoaula1;

import java.util.Scanner;

/**
 *
 * @author adrie
 */
public class Aula5 {
    public static void main (String[] args){
       /*for(int i = 0; i<10; i++){
        System.out.println("Bom dia!");
       }*/
       //For INFINITO
       /*for (;;){
           System.out.println("Adrielly é linda");
       }*/
       //INFINITO COM QUANTIDADE
       /*int n = 0;
       for (;;){
           n = n + 1;
           System.out.println("O programa já foi executado " + n + " vezes");
       }*/
       //Comando para SORTEIO: Math.round(Math.random() * 10);
       //SORTEIO
       /*long numero = Math.round(Math.random() * 10);
       long chute;
       Scanner leitor = new Scanner (System.in);
       System.out.println("Digite um número");
       chute = leitor.nextLong();
       while (numero != chute){
           System.out.println("Digete um número entre 1 e 10");
           chute = leitor.nextLong();
       }
       System.out.println("Você acertou");*/
       /*QUADRADO DO-While
       int numero;
       int quadrado;
       Scanner leitor = new Scanner(System.in);
       do{
           System.out.println("Digite um número");
           numero = leitor.nextInt();
           quadrado = numero * numero;
           System.out.println(quadrado);
       } while (numero != 0);
       System.out.println("FIM");*/
       /*int i = 0;
       while(i <= 15){
           if (i % 2 == 0){
               System.out.println(i);
              }
            i = i + 1;
       }*/
         
       }
    }

