package projetoaula1;


import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author adrie
 */
public class Aula9 {

    public static void main(String[] args){
        //Scanner leitor = new Scanner(System.in);
            //FATORIAL
        /*System.out.println("Digite um número");
        int numero = leitor.nextInt();
        int fat = fatorial(numero);
        if (fat > 0 ) {
            System.out.println("O fatorial desse número é " + fat);
        }
        else {
            System.out.println("Não existe fatorial para números negativos");
        }
    }
    public static int fatorial (int numero){
        int fat;
        if (numero < 0){
            fat = -1;
        } else if (numero == 0){
            fat = 1;
        } else {
            fat = fatorial(numero-1)*numero;
            }
        return fat;
    }*/
        /*System.out.println("Digite o número a ser dobrado");
        int numero = leitor.nextInt();
        System.out.println("Digite o limite");
        int limite = leitor.nextInt();
        System.out.println(dobrarNumeroAteLimite(numero, limite));
    }     
    public static int dobrarNumeroAteLimite(int numero, int limite){
        for (int aux = numero*2; aux < limite; aux = numero*2){
            numero = aux;
        }
        return numero;*/
        //IMPRIMIR COPA DO MUNDO
        /*Main();
    }
    public static void Main(){
        System.out.println("Copa do Mundo");
        Main();*/
     }
}
