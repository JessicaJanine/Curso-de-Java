/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoaula1;
import java.util.Scanner;
/**
 *
 * @author adrie
 */
public class Aula4 {
    public static void main(String[] args){
        //CALCULA A MÉDIA
        /*float nota1, nota2, nota3, nota4, media;
        Scanner leitor = new Scanner(System.in);
        System.out.println("Digite as quatro notas que você tirou");
        nota1 = leitor.nextFloat();
        nota2 = leitor.nextFloat();
        nota3 = leitor.nextFloat();
        nota4 = leitor.nextFloat();
        media = (nota1 + nota2 + nota3 + nota4)/4;
        if (media >= 7){
            System.out.println("O aluno foi aprovado");
             System.out.println("Parabéns!");
        }
        if (media < 7){
            System.out.println("O aluno foi reprovado");
        }
        System.out.println("FIM");*/
        //MÚLTIPLO de 2
        /*
        double n1, n2, n3, n4, n5, soma;
        Scanner leitor = new Scanner(System.in);
        System.out.println("Digite 5 números");
        n1 = leitor.nextDouble();
        n2 = leitor.nextDouble();
        n3 = leitor.nextDouble();
        n4 = leitor.nextDouble();
        n5 = leitor.nextDouble();
        
       soma = n1 + n2 + n2 + n4 + n5;
       
       if (soma % 2 == 0){
           System.out.println("Múltiplo de 2");
       }*/
        
        //Triângulo de madeira
        /*float m1, m2, m3;
        Scanner leitor = new Scanner(System.in);
        System.out.println("Digite o tamanho dos pedaços de madeira");
        m1 = leitor.nextFloat();
        m2 = leitor.nextFloat();
        m3 = leitor.nextFloat();
        
        if (m1 < m2 + m3 && m2 < m1 + m3 && m3 < m1 + m2){
            System.out.println("Triângulo!!!!!");
        } */
        
        //Par ou Ímpar
        /*short n;
        Scanner leitor = new Scanner(System.in);
        System.out.println("Digite um número");
        n = leitor.nextShort();
        
        if (n % 2 == 0){
            System.out.println("É par");
        }
        else{
            System.out.println("É ímpar");
        }*/
        //Mais velhos
        /*String pessoa1, pessoa2;
        short idade1, idade2;
        Scanner leitor = new Scanner(System.in);
        System.out.println("Digite os nomes e as idades de duas pessoas");
        pessoa1 = leitor.nextLine();
        pessoa2 = leitor.nextLine();
        idade1 = leitor.nextShort();
        idade2 = leitor.nextShort();
        
        if (idade1 > idade2) {
            System.out.println("A mais velha é: "+pessoa1);
        }
        else {
            System.out.println("A mais velha é: "+pessoa2);
        }
        */
        //Maior ou igual
        /*int n1, n2;
        Scanner leitor = new Scanner (System.in);
        System.out.println("Digite 2 números");
        n1 = leitor.nextInt();
        n2 = leitor.nextInt();
        if (n1 == n2) { System.out.println("os números são iguais");}
        else if (n1 > n2){System.out.println(n1);}
        else if (n2 > n1) {System.out.println(n2);
        }
        */
        //Situação da sua nota
        /*float nota;
        Scanner leitor = new Scanner (System.in);
        System.out.println("Qual foi a sua nota?");
        nota = leitor.nextFloat();
        if (nota <= 3){
            System.out.println("Você precisa melhorar muito, muitíssimo");
         }
        else if (nota > 3 && nota < 7){
            System.out.println("Você está quase conseguindo");
        }
        else if (nota >= 7 && nota <9){
        System.out.println("Você conseguiu");
    }
        else if (nota >= 9){
            System.out.println("Você conseguiu com distinção");
        }*/
        //Encontrando uma palavra
        /*char letra;
        Scanner leitor = new Scanner (System.in);
        System.out.println("Digite uma letra");
        letra = leitor.nextLine().charAt(0);
        
        switch (letra){
            case 'A':
                System.out.println("Argentina");
            break;
            case 'B':
                System.out.println("Brasil");
            break;
            case 'J':
                System.out.println("Jamaica");
            break;
            case 'C': 
                System.out.println("Canada");
            break;
            default:
                System.out.println("País não encontrado");
        }*/
    char c;
    Scanner s = new Scanner(System.in);
    c = s.nextLine().charAt(1);
    
    }
}
        
    

