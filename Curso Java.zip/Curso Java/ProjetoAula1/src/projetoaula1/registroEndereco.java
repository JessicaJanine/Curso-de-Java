/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoaula1;

/**
 *
 * @author adrie
 */
public class registroEndereco {
    public String rua;
    public int numero;
    public String bairro;
    public String cidade;
    public String estado;
    public String CEP;
}
