/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoaula1;

/**
 *
 * @author adrie
 */
public class Soma {
    public static int gl = 20;
    private static int aa = 30, bb = 40, c = 50, d = 60;
    private static char v1= 'g', v2 = 'a', v3 = 't', v4 = 'o';
    public static String nome = "Jessica "
            + "Janine "
            + "de "
            + "Oliveira";
     
      
    
    public static void main (String args[]){     
        int a = 30;
        int b = 20;
        int media = (a+b)/2;
        System.out.println(media);
        System.out.println(gl);
        System.out.println(aa);
        System.out.println(bb);
        System.out.println(c);
        System.out.println(d);
        System.out.print(v1);
        System.out.print(v2);
        System.out.print(v3);
        System.out.println(v4);
        System.out.println(nome);
 
    }
    
}
