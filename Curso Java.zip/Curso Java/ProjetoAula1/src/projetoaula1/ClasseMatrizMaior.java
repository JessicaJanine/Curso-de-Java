/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoaula1;

import java.util.Scanner;

/**
 *
 * @author adrie
 */
public class ClasseMatrizMaior {
    public static void main (String[] args){
        Scanner leitor =  new Scanner(System.in);
        /*int linha, coluna;        
        System.out.println("Digite as dimensões da matriz");
        linha = leitor.nextInt();
        coluna = leitor.nextInt();
        int matriz [][] = new int[linha][coluna];
        for (int l = 0; l < matriz.length; l++){
            for (int c = 0; c <matriz[linha-1].length; c++){
                System.out.println("Digite o valor");
                matriz[l][c] = leitor.nextInt();
            }
        }
                int maior = matriz[0][0];
           for (int l = 0; l < matriz.length; l++){
            for (int c = 0; c <matriz[linha-1].length; c++){
                if (matriz[l][c]> maior){
                    maior = matriz[l][c];
                }
            }
               }
             System.out.println("O maior valor é" + maior);*/
            
       /* int matrizA[][] = new int [3][4];
        int matrizB[][] = new int [3][2];
        int matrizC[][] = new int [3][6];
        
        for (int i = 0; i < matrizA.length; i++){
            for (int j = 0; j < matrizA[i].length; j++){
                System.out.println("Digite os valores da primeira matriz");
                matrizA[i][j] = leitor.nextInt();
            }
        }
          for (int i = 0; i < matrizB.length; i++){
            for (int j = 0; j < matrizB[i].length; j++){
                System.out.println("Digite os valores da segunda matriz");
                matrizB[i][j] = leitor.nextInt();
            }
        }
           for (int i = 0; i < matrizC.length; i++){
               for (int j = 0; j < matrizA[i].length; j++){
                matrizC[i][j] = matrizA[i][j];   
                
               }
               for (int j = 4; j <matrizC[i].length; j++){
                   matrizC[i][j] = matrizB[i][j-4];
               }
               
           }
          System.out.println("A matriz C é");
          for (int i = 0; i < matrizC.length; i++){
              for(int j = 0; j < matrizC[i].length; j++){
                  System.out.print(matrizC[i][j] + " ");
              }
              System.out.println(" ");
          }*/
       
     
              
           }
       }
       
    


        
                
                
            
        
    
    
    

