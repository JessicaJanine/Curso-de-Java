/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoaula1;

import java.util.Scanner;

/**
 *
 * @author adrie
 */
public class Maior_que10 {
    public static void main (String[] args){
        Scanner leitor = new Scanner (System.in);
        System.out.println("Digite um número inteiro");
        int numero = leitor.nextInt();
        if (numero > 10){
            System.out.println("O número digitado é maior do que 10");
        }
    }
    
}
