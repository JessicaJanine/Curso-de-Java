/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoaula1;

import java.util.Scanner;

/**
 *
 * @author adrie
 */
public class Aula7 {
    //utilizar .equals para comparar se duas Strings são iguais. (== é recomendado apenas para dados primitivos).
    public static void main(String[] args){
        Scanner leitor =  new Scanner (System.in);
        /*System.out.println("Digite o primeiro nome");
        String nome1 = leitor.next();
        System.out.println("Digite o segundo nome");
        String nome2 = leitor.next();
        /*
        nome1 = nome1.toUpperCase(); Essas linhas convertem as strings tudo para maiúscula antes de comparar. Nesse caso, não faz diferença se as letras de entrada foram maiúsculas ou minúsculas.
        nome2 = nome2.toUpperCase(); 
        O comando .toLowerCase(); - Transformaria tudo em minúscula.
        */
       /* if (nome1.equals(nome2)){
            //nome1.equalsIgnoreCase(nome2); - Ignora se as letras que entraram são minúsculas ou maiúsculas na hora da comparação.
            System.out.println("Nomes iguais");
        } else {
            System.out.println("Nomes diferentes");
        }*/
        //Trabalhar com String como se ela fosse um vetor
        /*System.out.println("Digite uma palavra");
        String nome1 = leitor.next();
        System.out.println("Inverso");
        for (int i = nome1.length() -1; i >= 0; i--){
            if (i % 2 == 0){
            System.out.print(nome1.charAt(i));
            }
        }*/
        //ENCONTRAR A POSIÇÂO DE UM CARACTERE EM UM TEXTO
       /* System.out.println("Digite uma palavra");
        String nome1 = leitor.next();
        char ponto = '.';
        int inicio = 0;
        int posicao = nome1.indexOf(ponto);
        System.out.println("Existem ponto nas posições:");
        while (inicio < nome1.length() && posicao != -1){
            System.out.println(posicao);
            inicio = posicao + 1;
            posicao = nome1.indexOf(ponto, inicio);
        }*/
       
       
    }
}
