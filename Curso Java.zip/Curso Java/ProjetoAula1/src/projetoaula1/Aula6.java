/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoaula1;

import java.util.Scanner;

/**
 *
 * @author adrie
 */
public class Aula6 {
    public static void main (String[] args){
        // LER E IMPRIMIR NOTAS DE ALUNOS, COM A POSIÇÃO
        Scanner leitor = new Scanner(System.in);
        System.out.println("Digite o tamanho da turma");
        int quantidade = leitor.nextInt();
        double notas[] = new double[quantidade];
        for (int i = 0; i < quantidade; i++){
            System.out.println("Digite a nota do aluno" + i);
            notas[i] = leitor.nextDouble();
        }
        for (int i = 0; i < quantidade; i++){
          System.out.println(notas[i]+"-" + i);
        }
        /*LENDO E IMPRIMINDO VALORES COMENDO .LENGTH
        Scanner leitor = new Scanner(System.in);
        System.out.println("Digite a quantidade de valores");
        int [] valores = new int[leitor.nextInt()];
        System.out.println("Digite agora os valores");
        for (int i = 0; i < valores.length; i++){
            valores[i] = leitor.nextInt();
        }
        System.out.println("Valores digitados");
        for (int i = 0; i < valores.length; i++){
            System.out.println(valores[i]);
        }*/
        //MATRIZ
        /*Scanner leitor =  new Scanner(System.in);
        int matriz[][] = new int[leitor.nextInt()][leitor.nextInt()];
        System.out.println("Digite as dimensões da matriz");
        for (int linha = 1; linha < matriz.length; linha++){
            for (int coluna = 1; coluna <matriz[linha-1].length; coluna++){
                System.out.println("Digite o valor");
                matriz[linha-1][coluna-1] = leitor.nextInt();
            }
        }
               System.out.println("Lista dos valores");
               
            for (int linha = 0; linha < matriz.length; linha++){
                for (int coluna = 0; coluna < matriz.length; coluna++) {
                    System.out.println("Linha" + (linha+1)+(coluna+1)+":" + matriz[linha][coluna]);
                }
                
            }*/
        }
    }
    

