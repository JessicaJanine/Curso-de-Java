/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package projetoaula1;

import java.util.Scanner;

/**
 * AULA DE MÓDULOS (FUNÇÕES E PROCEDIMENTOS)
 * @author adrie
 */
public class Aula8 {
        public static final String APROVADO = "aprovado";
        public static final String REPROVADO = "reprovado";
        public static final String RECUPERACAO = "em recuperação";
    public static void main(String[] args){
        Scanner leitor = new Scanner(System.in);
        pegarNotas(leitor);
        pegarNotas(leitor);
        
    }
    //PROCEDIMENTO PEGAR NOTAS
    private static void pegarNotas(Scanner leitor){
        System.out.println("Digite a primeira nota");
        double nota1 = leitor.nextDouble();
        System.out.println("Digite a segunda nota");
        double nota2 = leitor.nextDouble();
        System.out.println("Digite a terceira nota");
        double nota3 = leitor.nextDouble();
        System.out.println("Digite a quarta nota");
        double nota4 = leitor.nextDouble();
        double media = calcularMedia(nota1, nota2, nota3, nota4);
        System.out.println("Sua média foi "+ media);
        System.out.println("Você está " + verificarSituacao(media));
        
    }
    //---------------
    //FUNÇÃO CALCULAR MÉDIA
    public static double calcularMedia(double nota1, double nota2, double nota3, double nota4){
        return(nota1 + nota2 + nota3 + nota4)/4;
    }
    //FUNÇÃO VERIFICAR SITUAÇÃO DO ALUNO
    public static String verificarSituacao(double media){
    if (media>=7){
return APROVADO;
} else if (media < 3){
return REPROVADO;
} else {
return RECUPERACAO;
}

        
    }
    
}
